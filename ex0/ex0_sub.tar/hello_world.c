#include <stdio.h>
//
// Created by itayt on 28/10/2024.
//
int main() {
    printf("Hello World!\n");
    printf("7.4 4.1\n");
}